/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useRef, useEffect } from 'react';
import { GoogleGenAI, ThinkingLevel, Modality } from "@google/genai";
import { 
  BookOpen, 
  Send, 
  Globe, 
  GraduationCap, 
  Languages, 
  ChevronDown, 
  Sparkles,
  User,
  Search,
  Sun,
  Moon,
  Menu,
  Image as ImageIcon,
  FileText,
  X,
  PlusCircle,
  Volume2,
  VolumeX,
  Loader2
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import ReactMarkdown from 'react-markdown';

// Initialize Gemini API
const apiKey = process.env.GEMINI_API_KEY || "";

interface Message {
  role: 'user' | 'ai';
  content: string;
  subject?: string;
  context?: string;
  image?: string;
  pdfName?: string;
  pdfData?: string;
  portalUrl?: string;
}

const COUNTRIES = [
  "India", "USA", "UK", "Australia", "Canada", "Germany", "France", "Japan", "China", "Brazil",
  "South Africa", "Nigeria", "Pakistan", "Bangladesh", "Sri Lanka", "Nepal", "Saudi Arabia",
  "UAE", "Egypt", "Russia", "South Korea", "Singapore", "Malaysia", "Indonesia", "Philippines",
  "Mexico", "Argentina", "Italy", "Spain", "Turkey", "Kenya", "Ghana", "Ethiopia", "Vietnam",
  "Thailand", "Iran", "Iraq", "Poland", "Netherlands", "Sweden", "Norway", "Denmark", "Finland",
  "New Zealand", "Portugal", "Greece", "Israel", "Switzerland", "Belgium"
];

const LANGUAGES = [
  { name: "English", code: "English" },
  { name: "हिन्दी (Hindi)", code: "Hindi" },
  { name: "اردو (Urdu)", code: "Urdu" },
  { name: "বাংলা (Bengali)", code: "Bengali" },
  { name: "العربية (Arabic)", code: "Arabic" },
  { name: "Français (French)", code: "French" },
  { name: "Deutsch (German)", code: "German" },
  { name: "Español (Spanish)", code: "Spanish" },
  { name: "Português (Portuguese)", code: "Portuguese" },
  { name: "Русский (Russian)", code: "Russian" },
  { name: "中文 (Chinese)", code: "Chinese" },
  { name: "日本語 (Japanese)", code: "Japanese" },
  { name: "한국어 (Korean)", code: "Korean" },
  { name: "Kiswahili (Swahili)", code: "Swahili" },
  { name: "தமிழ் (Tamil)", code: "Tamil" },
  { name: "తెలుగు (Telugu)", code: "Telugu" },
  { name: "मराठी (Marathi)", code: "Marathi" },
  { name: "ગુજરાતી (Gujarati)", code: "Gujarati" },
  { name: "ਪੰਜਾਬੀ (Punjabi)", code: "Punjabi" },
  { name: "Bahasa Indonesia", code: "Indonesian" },
  { name: "Bahasa Melayu", code: "Malay" },
  { name: "Türkçe (Turkish)", code: "Turkish" },
  { name: "Tiếng Việt (Vietnamese)", code: "Vietnamese" },
  { name: "ภาษาไทย (Thai)", code: "Thai" },
  { name: "فارسی (Persian)", code: "Persian" },
  { name: "Italiano (Italian)", code: "Italian" },
  { name: "Nederlands (Dutch)", code: "Dutch" },
  { name: "Polski (Polish)", code: "Polish" },
  { name: "Ελληνικά (Greek)", code: "Greek" },
  { name: "עברית (Hebrew)", code: "Hebrew" },
  { name: "አማርኛ (Amharic)", code: "Amharic" }
];

const GRADES = [
  "Grade 1 (Class 1)", "Grade 2 (Class 2)", "Grade 3 (Class 3)", "Grade 4 (Class 4)",
  "Grade 5 (Class 5)", "Grade 6 (Class 6)", "Grade 7 (Class 7)", "Grade 8 (Class 8)",
  "Grade 9 (Class 9)", "Grade 10 (Class 10)", "Grade 11 (Class 11)", "Grade 12 (Class 12)",
  "Undergraduate (University)", "Postgraduate (Masters)", "Competitive Exam Prep"
];

const SUBJECTS = [
  "Mathematics", "Science", "Physics", "Chemistry", "Biology", "English", "Hindi", "History", "Geography",
  "Computer Science", "Economics", "Political Science", "Accountancy", "Literature",
  "Environmental Science", "Psychology", "Statistics", "Art", "Music", "Physical Education", "General"
];

const QUICK_TOPICS = [
  { label: "Photosynthesis", prompt: "Explain photosynthesis step by step" },
  { label: "Pythagoras", prompt: "What is the Pythagoras theorem and how to use it?" },
  { label: "Newton's Laws", prompt: "Explain Newton's laws of motion with examples" },
  { label: "WW1 Causes", prompt: "What are the causes of World War 1?" },
  { label: "Digestion", prompt: "How does the human digestive system work?" },
  { label: "Quadratics", prompt: "Explain quadratic equations with examples" },
  { label: "Periodic Table", prompt: "What is the periodic table and how is it organized?" },
  { label: "DNA", prompt: "Explain DNA replication simply" }
];

export default function App() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState<number | null>(null);
  const [error, setError] = useState<React.ReactNode | null>(null);
  const [darkMode, setDarkMode] = useState(false);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [selectedPdf, setSelectedPdf] = useState<{ name: string, data: string } | null>(null);
  const [isSearchMode, setIsSearchMode] = useState(false);
  const [showPortal, setShowPortal] = useState<string | null>(null);
  const [showMobileMenu, setShowMobileMenu] = useState(false);
  
  const [country, setCountry] = useState('India');
  const [language, setLanguage] = useState('English');
  const [grade, setGrade] = useState('Grade 9 (Class 9)');
  const [subject, setSubject] = useState('Mathematics');

  const chatEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const pdfInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handlePdfUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && file.type === 'application/pdf') {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedPdf({
          name: file.name,
          data: reader.result as string
        });
      };
      reader.readAsDataURL(file);
    }
  };

  const generateQuiz = () => {
    const quizPrompt = `Generate a 5-question multiple-choice quiz about ${subject} for ${grade} level in ${country}. 
    Format the quiz clearly with questions and options. After the quiz, provide the correct answers with brief explanations.
    CRITICAL: Do NOT use dollar signs ($) for mathematical notation or symbols. Use proper Unicode symbols (e.g., ×, ÷, √, ², π, ±, ≤, ≥) or the [Formula: ...] tag for complex equations.`;
    handleSend(quizPrompt);
  };

  const handleFindBookPdf = () => {
    const newMode = !isSearchMode;
    setIsSearchMode(newMode);
    
    if (newMode && country === 'India') {
      const aiMessage: Message = {
        role: 'ai',
        content: `I've enabled **Search Mode**! Since you're studying in **India**, you can access all official NCERT textbooks directly. \n\nClick the button below to open the **NCERT Portal** inside this app, or use the link to visit the website.`,
        subject: 'Resources',
        context: 'India · NCERT',
        portalUrl: 'https://ncert.nic.in/textbook.php'
      };
      setMessages(prev => [...prev, aiMessage]);
    }
  };

  const handleSpeak = async (text: string, index: number) => {
    if (isSpeaking !== null) return;
    
    // Create a fresh instance to ensure we use the latest API key from the dialog
    const currentApiKey = process.env.GEMINI_API_KEY || (process.env as any).API_KEY || "";
    const currentGenAI = new GoogleGenAI({ apiKey: currentApiKey });

    setIsSpeaking(index);
    try {
      const response = await currentGenAI.models.generateContent({
        model: "gemini-2.5-flash-preview-tts",
        contents: [{ parts: [{ text: `Read this educational explanation clearly and encouragingly: ${text.slice(0, 1000)}` }] }],
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: { voiceName: 'Kore' },
            },
          },
        },
      });

      const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
      if (base64Audio) {
        const audioSrc = `data:audio/mp3;base64,${base64Audio}`;
        const audio = new Audio(audioSrc);
        audio.onended = () => setIsSpeaking(null);
        audio.onerror = () => setIsSpeaking(null);
        await audio.play();
      } else {
        setIsSpeaking(null);
      }
    } catch (err: any) {
      console.error("TTS Error:", err);
      const errorString = typeof err === 'string' ? err : JSON.stringify(err);
      const errorMsg = err?.message || "";
      
      if (errorString.includes("429") || errorString.includes("RESOURCE_EXHAUSTED") || errorMsg.includes("429") || errorMsg.includes("quota")) {
        setError(
          <div className="flex flex-col gap-2 p-1">
            <span className="font-bold text-red-600 dark:text-red-400">Voice Limit Reached</span>
            <span className="text-[10px]">The API quota is full. Please select your own API key to use voice features.</span>
            <button 
              onClick={() => (window as any).aistudio?.openSelectKey()}
              className="bg-gold text-navy px-3 py-1 rounded-lg font-bold text-[10px] uppercase w-fit"
            >
              Select API Key
            </button>
          </div>
        );
      }
      setIsSpeaking(null);
    }
  };

  const handleSend = async (text: string = input) => {
    if (!text.trim() && !selectedImage && !selectedPdf || isLoading) return;

    // Create a fresh instance to ensure we use the latest API key from the dialog
    const currentApiKey = process.env.GEMINI_API_KEY || (process.env as any).API_KEY || "";
    const currentGenAI = new GoogleGenAI({ apiKey: currentApiKey });

    if (!currentApiKey) {
      setError(
        <div className="flex flex-col gap-2">
          <span>Gemini API Key is missing. Please add it to the Secrets panel or select one.</span>
          <button 
            onClick={() => (window as any).aistudio?.openSelectKey()}
            className="bg-gold text-navy px-3 py-1 rounded-lg font-bold text-[10px] uppercase w-fit"
          >
            Select API Key
          </button>
        </div>
      );
      return;
    }

    setError(null);
    setShowMobileMenu(false);
    const userMessage: Message = { 
      role: 'user', 
      content: text, 
      image: selectedImage || undefined,
      pdfName: selectedPdf?.name,
      pdfData: selectedPdf?.data
    };
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    const currentImage = selectedImage;
    const currentPdf = selectedPdf;
    setSelectedImage(null);
    setSelectedPdf(null);
    setIsLoading(true);

    try {
      const parts: any[] = [{ text: getSystemPrompt() + "\n\nUser Question: " + text }];
      
      if (currentImage) {
        const base64Data = currentImage.split(',')[1];
        parts.push({
          inlineData: {
            data: base64Data,
            mimeType: "image/jpeg"
          }
        });
      }

      if (currentPdf) {
        const base64Data = currentPdf.data.split(',')[1];
        parts.push({
          inlineData: {
            data: base64Data,
            mimeType: "application/pdf"
          }
        });
      }

      const response = await currentGenAI.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: [
          {
            role: "user",
            parts: parts
          }
        ],
        config: {
          thinkingConfig: { thinkingLevel: ThinkingLevel.HIGH },
          tools: isSearchMode ? [{ googleSearch: {} }] : undefined,
        }
      });

      const aiMessage: Message = { 
        role: 'ai', 
        content: response.text || "I'm sorry, I couldn't generate a response.",
        subject: subject,
        context: `${country} · ${grade}`
      };
      
      setMessages(prev => [...prev, aiMessage]);
    } catch (error: any) {
      console.error("Gemini Error:", error);
      let errorMessage: React.ReactNode = "There was an error connecting to the study brain.";
      
      const errorString = typeof error === 'string' ? error : JSON.stringify(error);
      const errorMsg = error?.message || "";
      
      if (errorString.includes("429") || errorString.includes("RESOURCE_EXHAUSTED") || errorMsg.includes("429") || errorMsg.includes("quota")) {
        errorMessage = (
          <div className="flex flex-col gap-3 p-2">
            <div className="flex items-center gap-2 text-red-600 dark:text-red-400 font-bold">
              <X className="w-4 h-4" />
              <span>Study Limit Reached (Quota Exceeded)</span>
            </div>
            <p className="text-[11px] leading-relaxed">
              The shared API key has reached its limit. To continue studying without interruptions, please use your own Gemini API key.
            </p>
            <div className="flex flex-wrap gap-2 pt-1">
              <button 
                onClick={() => (window as any).aistudio?.openSelectKey()}
                className="bg-gold text-navy px-4 py-2 rounded-xl font-bold text-[11px] uppercase shadow-lg hover:bg-gold-light transition-all active:scale-95"
              >
                Select My Own API Key
              </button>
              <a 
                href="https://ai.google.dev/gemini-api/docs/billing" 
                target="_blank" 
                rel="noopener noreferrer"
                className="bg-navy-light text-gold border border-gold/30 px-4 py-2 rounded-xl font-bold text-[11px] uppercase hover:bg-gold hover:text-navy transition-all flex items-center"
              >
                Get a Free Key
              </a>
            </div>
          </div>
        );
      } else if (errorString.includes("403") || errorString.includes("PERMISSION_DENIED") || errorMsg.includes("permission")) {
        errorMessage = (
          <div className="flex flex-col gap-3 p-2">
            <div className="flex items-center gap-2 text-red-600 dark:text-red-400 font-bold">
              <X className="w-4 h-4" />
              <span>Permission Denied</span>
            </div>
            <p className="text-[11px] leading-relaxed">
              The current API key doesn't have permission to access the model or features (like Google Search). Please select a different API key or check your key's permissions.
            </p>
            <div className="flex flex-wrap gap-2 pt-1">
              <button 
                onClick={() => (window as any).aistudio?.openSelectKey()}
                className="bg-gold text-navy px-4 py-2 rounded-xl font-bold text-[11px] uppercase shadow-lg hover:bg-gold-light transition-all active:scale-95"
              >
                Select Different API Key
              </button>
            </div>
          </div>
        );
      } else if (errorMsg.includes("API key not valid") || errorString.includes("401") || errorString.includes("not found")) {
        errorMessage = (
          <div className="flex flex-col gap-2">
            <span>The API key provided is not valid or has expired.</span>
            <button 
              onClick={() => (window as any).aistudio?.openSelectKey()}
              className="bg-gold text-navy px-3 py-1 rounded-lg font-bold text-[10px] uppercase w-fit"
            >
              Update API Key
            </button>
          </div>
        );
      }
      
      setMessages(prev => [...prev, { 
        role: 'ai', 
        content: typeof errorMessage === 'string' ? errorMessage : "Study limit reached. Please select a new API key to continue."
      }]);
      setError(errorMessage);
    } finally {
      setIsLoading(false);
      inputRef.current?.focus();
    }
  };

  const getSystemPrompt = () => {
    const selectedLang = LANGUAGES.find(l => l.code === language || l.name === language)?.name || language;
    return `You are StudyMind AI — a world-class educational assistant and expert tutor. Your primary goal is to provide 100% accurate, curriculum-aligned, and pedagogically sound explanations for students.

CURRENT STUDENT CONTEXT:
- Country: ${country}
- Education Board/Curriculum: The standard national curriculum of ${country} (e.g., NCERT/CBSE for India, Common Core/AP for USA, GCSE/A-Levels for UK).
- Class/Grade: ${grade}
- Subject: ${subject}
- Response Language: ${selectedLang}

YOUR CORE GUIDELINES FOR ACCURACY & QUALITY:
1. **Curriculum Alignment**: You MUST align your answers with the specific curriculum of ${country}. Use the terminology, definitions, and methods taught in that region's standard textbooks.
2. **Step-by-Step Reasoning (Chain of Thought)**: For every problem, especially in Math and Science, you must think through the solution step-by-step before providing the final answer. Show every logical step clearly.
3. **Fact-Checking**: Before outputting any fact, date, formula, or definition, verify it against your internal knowledge base. Accuracy is your top priority.
4. **Grade Appropriateness**: Ensure the complexity of your explanation matches the ${grade} level. Do not use university-level concepts for a middle school student unless explicitly asked.
5. **Language Consistency**: Respond entirely in ${selectedLang.toUpperCase()}.
6. **No Dollar Signs for Math**: NEVER use dollar signs ($) to wrap mathematical formulas or symbols (e.g., avoid $x^2$). Instead, use proper Unicode symbols (e.g., ×, ÷, √, ², π, θ, α, β) or use the [Formula: ...] tag for complex equations. Use the actual currency symbol (e.g., ₹, $, £, €) ONLY when referring to money in a financial context.
7. **Book PDF Search**: If the user asks for a book PDF, use your search tools to find official, legal, and publicly accessible PDF links. 
   - **CRITICAL (India)**: If the user is in India and asks for textbooks, ALWAYS provide the link to the [Official NCERT Portal](https://ncert.nic.in/textbook.php) and mention they can open it directly in the app.
   - For other countries, prioritize official government education portals (e.g., OpenStax, Project Gutenberg).

TEACHING STYLE:
- **Clarity**: Use simple, direct language.
- **Examples**: Provide relevant real-world examples from ${country}'s context.
- **Formulas**: Use the format [Formula: ...] for all mathematical and scientific formulas.
- **Structure**: Use headings, bullet points, and numbered lists to make the information easy to digest.
- **Encouragement**: Be supportive and patient.

IF YOU ARE UNSURE:
If a question is ambiguous or you lack specific curriculum details for a very niche topic, provide the most accurate general scientific/academic explanation and advise the student to check their specific textbook for regional variations.

NEVER provide "hallucinated" or made-up facts. If you don't know, say you don't know.`;
  };

  const formatContent = (content: string) => {
    // Handle the custom [Formula: ...] tag
    const parts = content.split(/(\[Formula: [^\]]+\])/g);
    return parts.map((part, i) => {
      if (part.startsWith('[Formula:')) {
        const formula = part.slice(9, -1);
        return <div key={i} className="formula-box">{formula}</div>;
      }
      return <ReactMarkdown key={i}>{part}</ReactMarkdown>;
    });
  };

  return (
    <div className="flex flex-col h-screen bg-cream text-text-dark overflow-hidden">
      {/* Header */}
      <header className="bg-navy px-4 sm:px-8 flex items-center justify-between h-16 border-b-2 border-gold shrink-0 transition-colors duration-300">
        <div className="flex items-center gap-3">
          <button 
            onClick={() => setShowMobileMenu(!showMobileMenu)}
            className="md:hidden p-2 -ml-2 text-gold hover:bg-navy-light rounded-lg transition-colors"
          >
            <Menu className="w-6 h-6" />
          </button>
          <div className="w-8 h-8 sm:w-9 sm:h-9 bg-gold rounded-lg flex items-center justify-center font-serif text-base sm:text-lg text-navy font-bold">
            S
          </div>
          <span className="font-serif text-xl sm:text-2xl text-white font-semibold tracking-tight">
            Study<span className="text-gold">Mind</span> AI
          </span>
        </div>
        <div className="flex items-center gap-4">
          <button 
            onClick={() => (window as any).aistudio?.openSelectKey()}
            className="hidden sm:flex items-center gap-2 bg-navy-light border border-gold/30 text-gold-light text-[10px] font-bold px-3 py-1.5 rounded-lg tracking-wider hover:bg-gold hover:text-navy transition-all uppercase"
          >
            <Sparkles className="w-3 h-3" />
            API Settings
          </button>
          <button 
            onClick={() => setDarkMode(!darkMode)}
            className="p-2 rounded-full hover:bg-navy-light text-gold transition-colors"
            title={darkMode ? "Switch to Light Mode" : "Switch to Dark Mode"}
          >
            {darkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
          </button>
          <div className="hidden sm:block bg-navy-light border border-gold/30 text-gold-light text-xs font-medium px-3 py-1 rounded-full tracking-wider">
            All Countries · All Classes
          </div>
        </div>
      </header>

      <div className="flex flex-1 overflow-hidden relative">
        {/* Sidebar / Mobile Menu Overlay */}
        <AnimatePresence>
          {showMobileMenu && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowMobileMenu(false)}
              className="md:hidden absolute inset-0 bg-black/50 z-40 backdrop-blur-sm"
            />
          )}
        </AnimatePresence>

        {/* Sidebar */}
        <aside className={`
          fixed md:static inset-y-0 left-0 z-40 w-72 bg-white dark:bg-dark-card border-r border-border-custom dark:border-dark-border flex flex-col overflow-y-auto transition-all duration-300 ease-in-out
          ${showMobileMenu ? 'translate-x-0 shadow-2xl' : '-translate-x-full md:translate-x-0'}
        `}>
          <div className="p-5 flex justify-between items-center md:hidden border-b border-border-custom dark:border-dark-border bg-navy text-white">
            <span className="font-bold tracking-wider uppercase text-xs">Curriculum Settings</span>
            <button onClick={() => setShowMobileMenu(false)} className="p-1 hover:bg-white/10 rounded-full">
              <X className="w-5 h-5" />
            </button>
          </div>
          <div className="p-5 space-y-6">
            <div>
              <label className="text-[10px] font-semibold tracking-widest uppercase text-text-light dark:text-dark-text-muted mb-2 block">Country</label>
              <div className="relative">
                <select 
                  value={country}
                  onChange={(e) => {
                    setCountry(e.target.value);
                    setShowMobileMenu(false);
                  }}
                  className="w-full p-2.5 border border-border-custom dark:border-dark-border rounded-lg text-sm bg-cream dark:bg-dark-bg dark:text-dark-text appearance-none focus:outline-none focus:border-gold transition-colors"
                >
                  {COUNTRIES.map(c => <option key={c} value={c}>{c}</option>)}
                </select>
                <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-text-light dark:text-dark-text-muted pointer-events-none" />
              </div>
            </div>

            <div>
              <label className="text-[10px] font-semibold tracking-widest uppercase text-text-light dark:text-dark-text-muted mb-2 block">Language</label>
              <div className="relative">
                <select 
                  value={language}
                  onChange={(e) => {
                    setLanguage(e.target.value);
                    setShowMobileMenu(false);
                  }}
                  className="w-full p-2.5 border border-border-custom dark:border-dark-border rounded-lg text-sm bg-cream dark:bg-dark-bg dark:text-dark-text appearance-none focus:outline-none focus:border-gold transition-colors"
                >
                  {LANGUAGES.map(l => <option key={l.code} value={l.code}>{l.name}</option>)}
                </select>
                <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-text-light dark:text-dark-text-muted pointer-events-none" />
              </div>
            </div>

            <div>
              <label className="text-[10px] font-semibold tracking-widest uppercase text-text-light dark:text-dark-text-muted mb-2 block">Grade / Class</label>
              <div className="relative">
                <select 
                  value={grade}
                  onChange={(e) => {
                    setGrade(e.target.value);
                    setShowMobileMenu(false);
                  }}
                  className="w-full p-2.5 border border-border-custom dark:border-dark-border rounded-lg text-sm bg-cream dark:bg-dark-bg dark:text-dark-text appearance-none focus:outline-none focus:border-gold transition-colors"
                >
                  {GRADES.map(g => <option key={g} value={g}>{g}</option>)}
                </select>
                <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-text-light dark:text-dark-text-muted pointer-events-none" />
              </div>
            </div>

            <div>
              <label className="text-[10px] font-semibold tracking-widest uppercase text-text-light dark:text-dark-text-muted mb-2 block">Subject</label>
              <div className="relative">
                <select 
                  value={subject}
                  onChange={(e) => {
                    setSubject(e.target.value);
                    setShowMobileMenu(false);
                  }}
                  className="w-full p-2.5 border border-border-custom dark:border-dark-border rounded-lg text-sm bg-cream dark:bg-dark-bg dark:text-dark-text appearance-none focus:outline-none focus:border-gold transition-colors"
                >
                  {SUBJECTS.map(s => <option key={s} value={s}>{s}</option>)}
                </select>
                <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-text-light dark:text-dark-text-muted pointer-events-none" />
              </div>
            </div>
          </div>

          <div className="h-px bg-cream-dark dark:bg-dark-border mx-5 my-2" />

          <div className="p-5">
            <label className="text-[10px] font-semibold tracking-widest uppercase text-text-light dark:text-dark-text-muted mb-3 block">Quick Topics</label>
            <div className="flex flex-wrap gap-2">
              {QUICK_TOPICS.map(topic => (
                <button
                  key={topic.label}
                  onClick={() => {
                    handleSend(topic.prompt);
                    setShowMobileMenu(false);
                  }}
                  className="px-3 py-1.5 rounded-full bg-cream-dark dark:bg-dark-bg border border-border-custom dark:border-dark-border text-xs text-text-mid dark:text-dark-text-muted hover:bg-navy hover:text-white dark:hover:bg-gold dark:hover:text-navy hover:border-navy transition-all cursor-pointer"
                >
                  {topic.label}
                </button>
              ))}
            </div>
          </div>

          <div className="p-5">
            <button
              onClick={() => {
                setShowPortal('https://ncert.nic.in/textbook.php');
                setShowMobileMenu(false);
              }}
              className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-navy text-gold font-bold hover:bg-navy-light transition-all shadow-md active:scale-95 border border-gold/30"
            >
              <BookOpen className="w-4 h-4" />
              NCERT Library
            </button>
          </div>

          <div className="p-5">
            <button
              onClick={() => {
                setShowPortal('https://ncert.nic.in/textbook.php');
                setShowMobileMenu(false);
              }}
              className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-white dark:bg-dark-card border border-border-custom dark:border-dark-border text-text-mid dark:text-dark-text hover:border-gold font-bold transition-all shadow-md active:scale-95"
            >
              <Search className="w-4 h-4" />
              Find Book PDF
            </button>
          </div>

          <div className="p-5">
            <button
              onClick={() => {
                generateQuiz();
                setShowMobileMenu(false);
              }}
              className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-gold text-navy font-bold hover:bg-gold-light transition-all shadow-md active:scale-95"
            >
              <FileText className="w-4 h-4" />
              Generate Quiz
            </button>
          </div>

          <div className="mt-auto p-5">
            <div className="bg-navy rounded-xl p-4 shadow-lg">
              <div className="text-[10px] font-semibold tracking-widest uppercase text-gold mb-2">Current Session</div>
              <div className="space-y-1.5">
                <div className="flex items-center gap-2 text-xs text-white/80">
                  <div className="w-1.5 h-1.5 rounded-full bg-gold" />
                  {country}
                </div>
                <div className="flex items-center gap-2 text-xs text-white/80">
                  <div className="w-1.5 h-1.5 rounded-full bg-gold" />
                  {grade.split(' (')[0]}
                </div>
                <div className="flex items-center gap-2 text-xs text-white/80">
                  <div className="w-1.5 h-1.5 rounded-full bg-gold" />
                  {subject}
                </div>
                <div className="flex items-center gap-2 text-xs text-white/80">
                  <div className="w-1.5 h-1.5 rounded-full bg-gold" />
                  {language}
                </div>
              </div>
            </div>
          </div>
        </aside>

        {/* Chat Area */}
        <main className="flex-1 flex flex-col overflow-hidden">
          <div className="flex-1 overflow-y-auto p-8 space-y-6">
            <AnimatePresence mode="popLayout">
              {messages.length === 0 ? (
                <motion.div 
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="flex flex-col items-center justify-center text-center py-12 gap-8"
                >
                  <div className="w-20 h-20 bg-navy dark:bg-gold rounded-2xl flex items-center justify-center text-4xl shadow-xl transition-colors duration-300">
                    📚
                  </div>
                  <div className="space-y-3">
                    <h1 className="font-serif text-4xl text-navy dark:text-gold font-bold leading-tight transition-colors duration-300">
                      Your Personal<br /><span className="text-gold dark:text-white">Study AI</span>
                    </h1>
                    <p className="text-text-light dark:text-dark-text-muted max-w-md text-lg transition-colors duration-300">
                      Ask any question from any subject, any country's curriculum, in any language. Get clear, accurate answers — just like a great teacher.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 w-full max-w-xl">
                    {[
                      { s: "Biology", t: "Explain osmosis with a real life example", p: "Explain the concept of osmosis with a real life example" },
                      { s: "Maths", t: "Find the roots of x² - 5x + 6 = 0", p: "Solve this: find the roots of x² - 5x + 6 = 0" },
                      { s: "Literature", t: "Main themes in Romeo and Juliet", p: "What are the main themes in Shakespeare's Romeo and Juliet?" },
                      { s: "Physics", t: "How does gravity work?", p: "Explain how gravity works and why things fall down" }
                    ].map((ex, i) => (
                      <button
                        key={i}
                        onClick={() => handleSend(ex.p)}
                        className="bg-white dark:bg-dark-card border border-border-custom dark:border-dark-border rounded-xl p-4 text-left hover:border-gold hover:bg-cream/30 dark:hover:bg-navy/30 transition-all group shadow-sm"
                      >
                        <div className="text-[10px] font-semibold tracking-widest uppercase text-gold mb-1 group-hover:text-gold-light transition-colors">{ex.s}</div>
                        <div className="text-sm text-text-mid dark:text-dark-text font-medium">{ex.t}</div>
                      </button>
                    ))}
                  </div>
                </motion.div>
              ) : (
                messages.map((msg, i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className={`flex gap-4 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                  >
                    {msg.role === 'ai' && (
                      <div className="w-9 h-9 rounded-full bg-navy flex items-center justify-center text-gold font-serif text-lg shrink-0 mt-1 shadow-md">
                        S
                      </div>
                    )}
                    <div className="flex flex-col max-w-[80%]">
                      <div className={`rounded-2xl px-5 py-4 text-[15px] leading-relaxed shadow-sm transition-colors duration-300 ${
                        msg.role === 'user' 
                          ? 'bg-navy dark:bg-gold text-white dark:text-navy rounded-tr-none' 
                          : 'bg-white dark:bg-dark-card border border-border-custom dark:border-dark-border text-text-dark dark:text-dark-text rounded-tl-none'
                      }`}>
                        {msg.image && (
                          <div className="mb-3 rounded-lg overflow-hidden border border-border-custom dark:border-dark-border">
                            <img src={msg.image} alt="Uploaded context" className="max-w-full h-auto" referrerPolicy="no-referrer" />
                          </div>
                        )}
                        {msg.pdfName && (
                          <div className="mb-3 flex items-center gap-2 bg-cream dark:bg-dark-bg border border-border-custom dark:border-dark-border rounded-lg p-3">
                            <FileText className="w-5 h-5 text-gold" />
                            <span className="text-xs font-medium text-text-dark dark:text-dark-text">{msg.pdfName}</span>
                          </div>
                        )}
                        <div className="markdown-body">
                          {formatContent(msg.content)}
                        </div>
                        {msg.portalUrl && (
                          <button
                            onClick={() => setShowPortal(msg.portalUrl!)}
                            className="mt-4 w-full flex items-center justify-center gap-2 py-2.5 rounded-xl bg-gold text-navy font-bold hover:bg-gold-light transition-all shadow-sm active:scale-95"
                          >
                            <BookOpen className="w-4 h-4" />
                            Open {country === 'India' ? 'NCERT' : 'Book'} Portal
                          </button>
                        )}
                      </div>
                      {msg.role === 'ai' && msg.subject && (
                        <div className="flex items-center justify-between mt-2">
                          <div className="flex items-center gap-2">
                            <span className="bg-cream-dark dark:bg-dark-bg border border-border-custom dark:border-dark-border rounded-full px-2.5 py-0.5 text-[10px] font-semibold text-text-mid dark:text-dark-text-muted uppercase tracking-wider transition-colors duration-300">
                              {msg.subject}
                            </span>
                            <span className="text-[10px] text-text-light dark:text-dark-text-muted font-medium uppercase tracking-wider transition-colors duration-300">
                              {msg.context}
                            </span>
                          </div>
                          
                          <button
                            onClick={() => handleSpeak(msg.content, i)}
                            disabled={isSpeaking !== null}
                            className={`p-1.5 rounded-full transition-all ${
                              isSpeaking === i 
                                ? 'bg-gold text-navy animate-pulse' 
                                : 'text-text-light dark:text-dark-text-muted hover:bg-cream dark:hover:bg-dark-bg hover:text-gold'
                            }`}
                            title="Listen to explanation"
                          >
                            {isSpeaking === i ? (
                              <Loader2 className="w-3.5 h-3.5 animate-spin" />
                            ) : (
                              <Volume2 className="w-3.5 h-3.5" />
                            )}
                          </button>
                        </div>
                      )}
                    </div>
                    {msg.role === 'user' && (
                      <div className="w-9 h-9 rounded-full bg-gold flex items-center justify-center text-navy font-bold text-sm shrink-0 mt-1 shadow-md">
                        U
                      </div>
                    )}
                  </motion.div>
                ))
              )}
            </AnimatePresence>
            
            {isLoading && (
              <div className="flex gap-4 justify-start">
                <div className="w-9 h-9 rounded-full bg-navy flex items-center justify-center text-gold font-serif text-lg shrink-0 mt-1 shadow-md">
                  S
                </div>
                <div className="bg-white border border-border-custom rounded-2xl rounded-tl-none px-5 py-4 flex gap-1.5 items-center shadow-sm">
                  <motion.div animate={{ y: [0, -5, 0] }} transition={{ repeat: Infinity, duration: 1, delay: 0 }} className="w-1.5 h-1.5 rounded-full bg-text-light" />
                  <motion.div animate={{ y: [0, -5, 0] }} transition={{ repeat: Infinity, duration: 1, delay: 0.2 }} className="w-1.5 h-1.5 rounded-full bg-text-light" />
                  <motion.div animate={{ y: [0, -5, 0] }} transition={{ repeat: Infinity, duration: 1, delay: 0.4 }} className="w-1.5 h-1.5 rounded-full bg-text-light" />
                </div>
              </div>
            )}
            <div ref={chatEndRef} />
          </div>

          {/* Input Area */}
          <div className="p-6 bg-cream dark:bg-dark-bg border-t border-border-custom dark:border-dark-border transition-colors duration-300">
            <div className="max-w-4xl mx-auto">
              {error && (
                <div className="mb-3 p-3 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 text-red-700 dark:text-red-400 text-xs font-medium rounded-xl flex items-center gap-2 animate-in fade-in slide-in-from-bottom-1">
                  <div className="w-1.5 h-1.5 rounded-full bg-red-500 shrink-0" />
                  {error}
                </div>
              )}

              {selectedImage && (
                <div className="mb-3 relative inline-block">
                  <img src={selectedImage} alt="Preview" className="w-24 h-24 object-cover rounded-xl border-2 border-gold shadow-md" referrerPolicy="no-referrer" />
                  <button 
                    onClick={() => setSelectedImage(null)}
                    className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-1 shadow-lg hover:bg-red-600 transition-colors"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </div>
              )}

              {selectedPdf && (
                <div className="mb-3 relative inline-block">
                  <div className="flex items-center gap-2 bg-white dark:bg-dark-card border-2 border-gold rounded-xl p-3 shadow-md">
                    <FileText className="w-6 h-6 text-gold" />
                    <span className="text-xs font-medium text-text-dark dark:text-dark-text max-w-[150px] truncate">{selectedPdf.name}</span>
                  </div>
                  <button 
                    onClick={() => setSelectedPdf(null)}
                    className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-1 shadow-lg hover:bg-red-600 transition-colors"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </div>
              )}

              <div className="bg-white dark:bg-dark-card border border-border-custom dark:border-dark-border rounded-2xl flex items-end gap-3 p-3 pl-5 shadow-sm focus-within:border-gold transition-all">
                <input 
                  type="file" 
                  ref={fileInputRef} 
                  onChange={handleImageUpload} 
                  accept="image/*" 
                  className="hidden" 
                />
                <input 
                  type="file" 
                  ref={pdfInputRef} 
                  onChange={handlePdfUpload} 
                  accept="application/pdf" 
                  className="hidden" 
                />
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="p-2 rounded-xl text-text-light dark:text-dark-text-muted hover:bg-cream dark:hover:bg-dark-bg transition-colors shrink-0"
                  title="Upload Image"
                >
                  <ImageIcon className="w-5 h-5" />
                </button>
                <button
                  onClick={() => pdfInputRef.current?.click()}
                  className="p-2 rounded-xl text-text-light dark:text-dark-text-muted hover:bg-cream dark:hover:bg-dark-bg transition-colors shrink-0"
                  title="Upload PDF Book/Notes"
                >
                  <FileText className="w-5 h-5" />
                </button>
                <textarea
                  ref={inputRef}
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault();
                      handleSend();
                    }
                  }}
                  placeholder="Ask any question from your textbook, concept, or topic..."
                  className="flex-1 bg-transparent border-none outline-none resize-none py-2 text-[15px] text-text-dark dark:text-dark-text placeholder:text-text-light dark:placeholder:text-dark-text-muted min-h-[24px] max-h-32"
                  rows={1}
                />
                <button
                  onClick={() => handleSend()}
                  disabled={(!input.trim() && !selectedImage && !selectedPdf) || isLoading}
                  className="w-10 h-10 rounded-xl bg-navy dark:bg-gold flex items-center justify-center text-gold dark:text-navy hover:bg-navy-light dark:hover:bg-gold-light disabled:bg-border-custom dark:disabled:bg-dark-border disabled:text-text-light dark:disabled:text-dark-text-muted transition-all shrink-0 shadow-md active:scale-95"
                >
                  <Send className="w-5 h-5" />
                </button>
              </div>
              <p className="text-center mt-3 text-[11px] text-text-light dark:text-dark-text-muted font-medium uppercase tracking-widest transition-colors duration-300">
                Studying for <span className="text-text-mid dark:text-gold">{country} · {grade.split(' (')[0]} · {subject}</span> · Select settings in sidebar
              </p>
            </div>
          </div>
        </main>
      </div>

      {/* Portal Modal */}
      <AnimatePresence>
        {showPortal && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 sm:p-8"
          >
            <motion.div 
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              className="bg-white dark:bg-dark-card w-full h-full max-w-6xl rounded-3xl overflow-hidden flex flex-col shadow-2xl border border-white/20"
            >
              <div className="p-4 sm:p-6 border-b border-border-custom dark:border-dark-border flex justify-between items-center bg-navy text-white">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-gold rounded-xl flex items-center justify-center text-navy">
                    <BookOpen className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="font-serif text-xl font-semibold leading-tight">Educational Portal</h3>
                    <p className="text-[10px] text-gold font-medium uppercase tracking-widest">{showPortal}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <button 
                    onClick={() => {
                      const url = showPortal;
                      setShowPortal(null);
                      setTimeout(() => setShowPortal(url), 10);
                    }}
                    className="p-2 hover:bg-white/10 rounded-full transition-colors"
                    title="Refresh"
                  >
                    <Loader2 className="w-5 h-5" />
                  </button>
                  <a 
                    href={showPortal} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="p-2 hover:bg-white/10 rounded-full transition-colors"
                    title="Open in new tab"
                  >
                    <Globe className="w-5 h-5" />
                  </a>
                  <button 
                    onClick={() => setShowPortal(null)} 
                    className="p-2 hover:bg-white/10 rounded-full transition-colors"
                  >
                    <X className="w-6 h-6" />
                  </button>
                </div>
              </div>
              <div className="flex-1 w-full bg-white relative flex flex-col items-center justify-center">
                <iframe 
                  src={showPortal} 
                  className="absolute inset-0 w-full h-full border-none z-10" 
                  title="Book Portal"
                />
                <div className="text-center p-8 space-y-4">
                  <div className="w-16 h-16 bg-cream dark:bg-dark-bg rounded-full flex items-center justify-center mx-auto">
                    <Globe className="w-8 h-8 text-gold animate-pulse" />
                  </div>
                  <h4 className="text-lg font-bold text-navy dark:text-gold">Loading Portal...</h4>
                  <p className="text-sm text-text-light dark:text-dark-text-muted max-w-xs mx-auto">
                    If the portal doesn't appear, it might be blocked by your browser or the website's security settings.
                  </p>
                  <a 
                    href={showPortal} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 px-6 py-3 bg-navy text-white rounded-xl font-bold hover:bg-navy-light transition-all"
                  >
                    Open in New Tab
                  </a>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
